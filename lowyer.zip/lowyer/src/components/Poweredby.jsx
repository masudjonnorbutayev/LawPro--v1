import React from 'react'

const Poweredby = () => {
  return (
    <div className='w-full bg-[#2C344C] py-[25px]'>
        <p className="norml-text text-center font-medium">Delta group | 2023</p>
    </div>
  )
}

export default Poweredby