import React from "react";

const Tagline = () => {
  return <section id="tagline-section">Delta Group 2023</section>;
};

export default Tagline;
