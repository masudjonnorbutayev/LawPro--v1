import React from "react";
import aiimg from "../assets/aiimg.svg";

const ChatAi = () => {
  return (
    <div className="ml-10">
      <img src={aiimg} alt="" />
    </div>
  );
};

export default ChatAi;
