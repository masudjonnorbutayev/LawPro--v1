import React from "react";

const Conatct = () => {
  return <div>Conatct</div>;
};

export default Conatct;
