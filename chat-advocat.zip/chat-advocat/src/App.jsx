import React from "react";
import Navbar from "./navbarcom/Navbar";

function App() {
  return (
    <div className="">
      <Navbar></Navbar>
    </div>
  );
}

export default App;
